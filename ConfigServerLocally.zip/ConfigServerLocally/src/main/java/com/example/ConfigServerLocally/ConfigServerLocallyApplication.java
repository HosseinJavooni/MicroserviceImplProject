package com.example.ConfigServerLocally;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServerLocallyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServerLocallyApplication.class, args);
	}

}
