package com.example.ConfigServerLocally;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServerLocallyApplicationTests {

	@Test
	void contextLoads() {
	}

}
